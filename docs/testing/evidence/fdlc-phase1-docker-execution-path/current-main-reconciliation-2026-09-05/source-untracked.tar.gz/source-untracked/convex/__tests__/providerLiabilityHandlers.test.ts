import { afterEach, expect, it, vi } from "vitest";
import {
  registerPriceVersion,
  createReservation,
  getReservation,
  reconcileUsage,
  reserveRequestInternal,
  recordUsageInternal,
} from "../factory/providerLiability";
import { liabilityDigest } from "../lib/providerLiability";
// Profile cryptographic/admission behavior has its own suite. Here vary its
// eligibility while exercising the actual liability handlers and worker fencing.
vi.mock("../lib/executionProfileAdmission", () => ({
  loadExecutionProfileAdmission: async (ctx: any) => ({
    eligible: ctx.profileEligible,
  }),
}));
afterEach(() => vi.unstubAllEnvs());
const hash = "sha256:" + "a".repeat(64);
function fixture() {
  const now = Date.now();
  const price = {
    schema: "factory-provider-price/v1",
    provider: "fixture",
    model: "fixture",
    api: "RESPONSES",
    currency: "USD",
    effectiveAt: now - 1000,
    expiresAt: now + 60000,
    source: "https://example.test/fixture",
    evidenceDigest: hash,
    inputNanoUsdPerToken: 1,
    outputNanoUsdPerToken: 2,
    maximumInputTokens: 10,
    maximumOutputTokens: 10,
    maximumPayloadBytes: 100,
    inputBound: "CONSERVATIVELY_BOUNDED",
    outputIncludesReasoning: true,
    inclusiveCacheWorstCase: true,
    otherBillableDimensions: "NONE",
  };
  const scope = {
    projectId: "project",
    repositoryId: "repo",
    workOrderId: "wo",
    workOrderRevision: 1,
    executionProfileId: "profile",
    executionProfileDigest: hash,
    modelRouteDigest: hash,
    priceDigest: liabilityDigest(price),
  };
  const rows: any = {
    reservation: {
      _id: "reservation",
      projectId: "project",
      workOrderId: "wo",
      executionProfileId: "profile",
      priceId: "price",
      snapshot: {
        schema: "factory-provider-reservation/v1",
        scope,
        maximumNanoUsd: 30,
        expiresAt: now + 60000,
        maximumRequests: 2,
        frozen: false,
        holds: [],
      },
    },
    run: {
      _id: "run",
      projectId: "project",
      workOrderId: "wo",
      workOrderRevisionNumber: 1,
      repositoryId: "repo",
      status: "RUNNING",
      executionProfileId: "profile",
      executionProfileDigest: hash,
      hostBindingId: "host",
      factoryDefinitionVersionId: "version",
      lease: {
        leaseId: "lease",
        workerId: "worker",
        workerSessionId: "session",
        workerGeneration: 1,
        expiresAt: now + 60000,
      },
    },
    wo: { _id: "wo", currentExecutionRunId: "run", currentRevisionNumber: 1 },
    host: {
      hostId: "worker",
      workerRuntime: { sessionId: "session", generation: 1 },
    },
    version: { budget: { maxCostUsd: 1 } },
    price: {
      _id: "price",
      projectId: "project",
      snapshot: price,
      digest: liabilityDigest(price),
    },
    project: { _id: "project", tenantId: "tenant" },
    tenant: { _id: "tenant", active: true },
  };
  const ctx: any = {
    profileEligible: true,
    auth: { getUserIdentity: async () => null },
    db: {
      get: async (id: string) => rows[id] ?? null,
      patch: vi.fn(async (id: string, p: any) => Object.assign(rows[id], p)),
      insert: vi.fn(async () => "event"),
      query: () => ({
        withIndex: () => ({
          first: async () => null,
          collect: async () => [],
          unique: async () => null,
        }),
        collect: async () => [],
      }),
    },
  };
  const args: any = {
    reservationId: "reservation",
    workflowRunId: "run",
    leaseId: "lease",
    generation: 1,
    requestId: "request",
    requestDigest: hash,
    payloadBytes: 10,
    outputTokens: 10,
  };
  return { ctx, rows, args, price };
}
const handler = (fn: unknown) =>
  (fn as { _handler: (ctx: any, args: any) => Promise<any> })._handler;
it("records one hold through the actual mutation and rejects a second full-balance request", async () => {
  const { ctx, rows, args } = fixture();
  await handler(reserveRequestInternal)(ctx, args);
  expect(rows.reservation.snapshot.holds).toHaveLength(1);
  await expect(
    handler(reserveRequestInternal)(ctx, { ...args, requestId: "second" }),
  ).rejects.toThrow("LIABILITY_EXHAUSTED");
});
it.each([
  "staleRun",
  "staleRevision",
  "cancel",
  "expiredLease",
  "lease",
  "generation",
  "hostSession",
  "hostGeneration",
  "profile",
  "profileDigest",
  "scope",
  "budget",
] as const)("fences %s at the mutation boundary", async (fault) => {
  const { ctx, rows, args } = fixture();
  switch (fault) {
    case "staleRun":
      rows.wo.currentExecutionRunId = "other";
      break;
    case "staleRevision":
      rows.wo.currentRevisionNumber = 2;
      break;
    case "cancel":
      rows.run.cancellationRequestedAt = 1;
      break;
    case "expiredLease":
      rows.run.lease.expiresAt = 1;
      break;
    case "lease":
      args.leaseId = "other";
      break;
    case "generation":
      args.generation = 2;
      break;
    case "hostSession":
      rows.host.workerRuntime.sessionId = "other";
      break;
    case "hostGeneration":
      rows.host.workerRuntime.generation = 2;
      break;
    case "profile":
      ctx.profileEligible = false;
      break;
    case "profileDigest":
      rows.run.executionProfileDigest = "other";
      break;
    case "scope":
      rows.run.repositoryId = "other";
      break;
    case "budget":
      rows.version.budget.maxCostUsd = 0;
      break;
  }
  await expect(handler(reserveRequestInternal)(ctx, args)).rejects.toThrow();
  expect(ctx.db.patch).not.toHaveBeenCalled();
});
it("denies another Attempt settling an existing hold", async () => {
  const { ctx, rows, args } = fixture();
  await handler(reserveRequestInternal)(ctx, args);
  rows.reservation.snapshot.holds[0].attemptId = "other";
  await expect(
    handler(recordUsageInternal)(ctx, {
      ...args,
      usage: { requestId: "request" },
    }),
  ).rejects.toThrow("Usage Attempt mismatch");
  expect(ctx.db.insert).not.toHaveBeenCalled();
});
it.each([
  registerPriceVersion,
  createReservation,
  getReservation,
  reconcileUsage,
])("denies anonymous public monetary authority", async (api) => {
  vi.stubEnv("MC_ALLOW_ANONYMOUS_COMPANY_CONTEXT", "0");
  const { ctx, args, price } = fixture();
  await expect(
    handler(api)(ctx, {
      ...args,
      projectId: "project",
      price,
      registrationKey: "key",
    }),
  ).rejects.toThrow();
  expect(ctx.db.patch).not.toHaveBeenCalled();
  expect(ctx.db.insert).not.toHaveBeenCalled();
});
